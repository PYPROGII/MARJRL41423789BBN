from scipy.io import arff
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import classification_report, accuracy_score,\
     confusion_matrix,ConfusionMatrixDisplay
# --
def process_MINST_for_ML(minstData):
    counter=0
    XlistTrain=[]
    ylistTrain=[]
    XlistTest=[]
    ylistTest=[]
    for element in minstData:
        counter+=1
        d_list=list(element)
        if counter <60001:
            XlistTrain.append(d_list[:784])
            ylistTrain.append(d_list[784:])
        else:
            XlistTest.append(d_list[:784])
            ylistTest.append(d_list[784:])
    return XlistTrain,ylistTrain,XlistTest,ylistTest
# --
def horizontal_plot(X,y,indexlist,maxwidth):
    # -- maxwidth is the number of subplots to be created
    
    fgr, ax = plt.subplots(1,maxwidth, figsize=(4,4))
    for w in range(maxwidth):
        digit=np.asarray(X[indexlist[w]])
        digit=digit.reshape(28,28)
        ax[w].imshow(digit,cmap='binary')
        ax[w].set_axis_off()                # Suppress the axis of each subplot
    fgr.tight_layout()
    plt.show()
#---
def plot_digits(X,y): 
    limit = 4
    fgr, ax = plt.subplots(4,1, figsize=(4,4))
    print("Vertical plot of the following digits")
    for d in range(limit):
        print(int(y[d*1000][0]))       # select digits 1000 apart - print value
        digit= np.asarray(X[d*1000])   # select digit images 1000 apart
        digit=digit.reshape(28,28)
        ax[d].imshow(digit,cmap='binary')
        ax[d].set_axis_off()
    fgr.tight_layout()
    plt.show()
    # --------
def predict_Class( XTrain,yTrain,XTest,yTest ):
    print("predict_Class")
    sgdClass = SGDClassifier(random_state=42)
    sgdClass.fit(XTrain,yTrain)
    pred = sgdClass.predict(XTest)
    print("prediction", len(pred))
    print("prediction type",type(pred))
    print(pred[20])
    print("Accuracy of test data:",accuracy_score(yTest,pred))
    print('\nClassification Report\n',classification_report(yTest,pred))
    lbl = ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    cnfMat=confusion_matrix(yTest,pred)
    display=ConfusionMatrixDisplay(confusion_matrix=cnfMat,display_labels=lbl)
    display.plot()
    plt.show()

def data_examination(data, meta):
    # - Examination of data
    print('data, shape',data.shape)
    print('meta type',type(meta))
    print("Selecting the second of the 70000 digits")
    print("data[1]")
    dg = data[1]              # -- First element of the data array
    print('\n\n')
    print('digit shape\t',dg.shape)
    print('digit length\t',len(dg)) 
    print('digit type\t',type(dg))
    print(dg)                 # -- Digit raw data
        
# ------
def main():

    data, meta = arff.loadarff('mnist_784.arff')
    data_examination(data, meta) # -- examination of a sample of the data.
    XTrain,yTrain,XTest,yTest = process_MINST_for_ML(data)
    print("Size of XTrain",len(XTrain),"yTrain",len(yTrain),"XTest",len(XTest),"yTest",len(yTest))
    predict_Class( XTrain,yTrain,XTest,yTest )
    

    plot_digits(XTrain,yTrain)  # -- Verical Plot

    # -- Select data of specific digits to plot for a visual
    
    # -- We are getting sample indexes of 0s, 6s, 8s, 2s in the
    # -- following lists. Ensure you are getting more than you will actually
    # -- display because the data is not ordered evenly by the sequence 0 1 2 3 4 5 6 7 8 9
    index_of_0s=[]
    index_of_6s=[]
    index_of_8s=[]
    index_of_2s=[]
    for i in range(len(yTrain)):
        if (i > 100 and i < 109) or (i > 1000 and i < 1019) or (i > 2100 and i < 2111) or \
           (i > 3200 and i < 3215) or (i > 4400 and i < 4421) or (i > 5100 and i < 5216):
            if int(yTrain[i][0])==0:
                index_of_0s.append(i)
            elif int(yTrain[i][0])==6:
                index_of_6s.append(i)
            elif int(yTrain[i][0])==8:
                index_of_8s.append(i)
            elif int(yTrain[i][0])==2:
                index_of_2s.append(i)
            if len(index_of_0s) > 5 and len(index_of_6s) > 5 and \
               len(index_of_8s) > 5 and len(index_of_2s) > 5:
                break
    # -- Plot your data. Use 6 characters on a single row ---
    horizontal_plot(XTrain,yTrain,index_of_0s,6)
    horizontal_plot(XTrain,yTrain,index_of_2s,6)
    horizontal_plot(XTrain,yTrain,index_of_6s,6)
    horizontal_plot(XTrain,yTrain,index_of_8s,6)
 
  
# -- Processing starts here
if __name__ == '__main__':
    main()
 
